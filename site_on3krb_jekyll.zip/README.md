# ON3KRB — GitHub Pages + Jekyll

Deze repo is klaar voor GitHub Pages met Jekyll.

## Structuur
- `index.html` = splash/entry (met morse player)
- `inner.html` = main hub (about + latest 3 posts)
- `blog.html` = blog overzicht
- `_layouts/default.html` = navigatie + footer + basis layout
- `_layouts/post.html` = layout voor blog posts (+ `css/post.css`)
- `_posts/` = Markdown posts

## Starten op GitHub Pages
1. Push alles naar GitHub
2. Settings → Pages → Source: `Deploy from a branch` (bv. `main` / `/root`)
3. Jekyll bouwt automatisch.
